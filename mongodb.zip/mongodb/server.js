const express = require("express");
const app = express();
const mongodb = require("mongodb")
const client = mongodb.MongoClient;
let dbinstance;
client.connect("mongodb+srv://Shubham:4321@database.jzu6gw9.mongodb.net/?retryWrites=true&w=majority&appName=DataBase").then((data) => {
      console.log("connected");
      dbinstance = data.db("test");
})
app.get("/home", (req, res) => {
      let arr;
  dbinstance.collection("simples").find({}).toArray().then((data)=>{
      arr = data;
      console.log(typeof data);
  })
      dbinstance.collection("simples").updateOne({"name" : "shubham"},{$set: {"name" : "somnath"}});
      //insertOne
      //insertMany
      //deleteOne
      //deleteMany
      res.send("ok");
})

app.listen(3000);
